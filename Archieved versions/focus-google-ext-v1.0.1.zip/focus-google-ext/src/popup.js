$(document).on('click', '.utility', function() {
	const method_choosen = $(this).attr('data-method');

	chrome.tabs.executeScript({
		code: `focus_ext_method = '${method_choosen}';`
	}, function() {
		chrome.tabs.executeScript({
			file: 'src/inject.js'
		}, function() {
			window.close();
		})
	});
});